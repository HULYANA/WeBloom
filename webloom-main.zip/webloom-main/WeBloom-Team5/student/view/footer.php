<div class="footer-cntr">
    <h2>Your Knowledge, Your Test,<br>Your Results.</h2><br>
    <table>
        <tr>
            <th>USEFUL</th>
            <th>LEGAL</th>
            <th>UPDATES</th>
        </tr>
        <tr>
            <td><a href="studHome.php#surveyContainer" class="footer-btn">questionnaires</a></td>
            <td><button class="footer-btn">privacy policy</button></td>
            <td><button class="footer-btn">facebook</button></td>
        </tr>
        <tr>
            <td><a href="studAccounts.php?section=activities" class="footer-btn">history</a></td>
            <td><button class="footer-btn">terms & conditions</button></td>
            <td><button class="footer-btn">g-mail</button></td>
        </tr>
    </table>
    <div style="display: flex; justify-content: space-between; width: 100%; position: absolute;">
        <p style="margin-left: 16%; position: absolute; transform: translateY(60px);">Powered by WeBloom</p>
        <p style="margin-left: 76%; position: absolute; transform: translateY(60px);">© 2024 WeBloom / 9373</p>
    </div>
    <h1>SURVEYTES</h1>
</div>
