<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "webloom";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT q.questionText AS question, 
               q.questionID AS question_id, 
               q.categoryID AS category_id, 
               q.questionType AS type, 
               c.choice 
        FROM questions q
        LEFT JOIN choices c ON q.questionID = c.questionID
        ORDER BY q.questionID";
$result = $conn->query($sql);

$questions = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $questions[$row['question_id']]['question'] = $row['question'];
        $questions[$row['question_id']]['category_id'] = $row['category_id'];
        $questions[$row['question_id']]['type'] = $row['type'];
        $questions[$row['question_id']]['choices'][] = $row['choice'];
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category_id = $_POST['category_id'];
    $question = $_POST['question'];
    $type = $_POST['type'];
    $choices = explode(',', $_POST['choices']); 

    $stmt = $conn->prepare("INSERT INTO questions (categoryID, questionText, questionType) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $category_id, $question, $type);
    if ($stmt->execute()) {
        $question_id = $stmt->insert_id;

        foreach ($choices as $choice) {
            $choice = trim($choice);
            $stmt = $conn->prepare("INSERT INTO choices (questionID, choice) VALUES (?, ?)");
            $stmt->bind_param("is", $question_id, $choice);
            $stmt->execute();
        }
        $_SESSION['successMessage'] = "Question added successfully!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Edit / Delete</title>
    <link rel="stylesheet" type="text/css" href="../../admin/assets/css/edit_Delete_Survey.css">
</head>

<body>
    <header>
        <div class="left-section">
            <p><span id="title">sur</span>v<span id="title">e</span>ytes</p>
        </div>
        <div class="right-section">
            <ul class="nav">
                <li><a href="#">home</a></li>
                <li><a href="#">surveys</a></li>
                <li><a href="#">drafts</a></li>
                <li><a href="#">questions</a></li>
                <li><a href="#">logout</a></li>
            </ul>
        </div>
    </header>

    <main>
        <div class="search-container">
            <div class="search-icon">
                <img src="../../admin/assets/imgs/search-icon.png" alt="Search Icon">
            </div>    
            <input type="text" class="search-input" placeholder="Search...">
            <button class="filter-button">
                <img src="../../admin/assets/imgs/filter-icon.png" alt="Filter Icon">
            </button>
        </div>

        <div class="add-question">
            <button class="add-new-question">
                + Add new Question
            </button>
        </div>

        <div class="question-container">
            <?php foreach ($questions as $question_id => $question_data): ?>
                <div class="button-container">
                    <button class="delete">delete</button>
                    <button class="edit">edit</button>
                </div>
                <table class="styled-table">
                    <tr class="header-row">
                        <td colspan="2" class="question-cell">Question</td>
                        <td>Question ID</td>
                        <td><?php echo $question_id; ?></td>
                        <td>Category</td>
                        <td><?php echo $question_data['category_id'];?></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <?php echo $question_data['question']; ?>
                        </td>
                        <td colspan="4" class="type-cell">Type:<br><?php echo $question_data['type']; ?></td>
                    </tr>
                    <tr class="options-header">
                        <td colspan="6">Options</td>
                    </tr>
                    <?php foreach ($question_data['choices'] as $choice): ?>
                        <tr>
                            <td colspan="6"><?php echo $choice; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endforeach; ?>
        </div>
        <div id="addQuestionModal" class="modal" style="display: none;">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2 id="add-label">Add New Question</h2>
                <table class="add-question-table">
                    <form id="addQuestionForm" method="POST" action="edit_Delete_Survey">
                        <tr class="header-row">
                            <td>
                                <label for="category_id">Category ID:</label>
                            </td>
                            <td>
                                <select id="category_id" name="category_id" required>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                                <option value="13">13</option>
                                <option value="14">14</option>
                                <option value="15">15</option>
                                <option value="16">16</option>
                                <option value="17">17</option>
                                <option value="18">18</option>
                                <option value="19">19</option>
                                </select>
                            </td>
                            <td>
                                <label for="type">Type:</label>
                            </td>
                            <td>
                                <select id="type" name="type" required>
                                <option value="Multiple Choice">Multiple Choice</option>
                                <option value="Likert Scale">Likert Scale</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="question">Question:</label>
                            </td>
                            <td colspan="3">
                                <textarea id="question" name="question" placeholder="Input question..." required></textarea>
                            </td>
                        </tr>
                        <tr class="options-header">
                            <td>
                                <label for="choices">Choices (comma-separated):</label>
                            </td>
                            <td colspan="3">
                                <textarea id="choices" name="choices" placeholder="Input choices..." required></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4" class="submit-row">
                            <button type="submit" id="add-question">Add Question</button>
                            </td>    
                        </tr>
                    </form>
                </table>
            </div>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
            document.querySelector('.add-new-question').onclick = function() {
                document.getElementById('addQuestionModal').style.display = 'block';
            }

            window.closeModal = function() {
                document.getElementById('addQuestionModal').style.display = 'none';
            }

            window.onclick = function(event) {
                if (event.target == document.getElementById('addQuestionModal')) {
                    closeModal();
                }
            }

            document.querySelector('.close').onclick = function() {
                closeModal();
            }

            <?php if (isset($_SESSION['successMessage'])): ?>
                alert("<?php echo $_SESSION['successMessage']; ?>");
                <?php unset($_SESSION['successMessage']);?>
            <?php endif; ?>
            
        });
        </script>
    </main>
</body>

</html>