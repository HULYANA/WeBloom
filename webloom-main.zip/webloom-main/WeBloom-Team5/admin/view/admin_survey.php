<?php
include 'C:\wamp64\www\webloom\WeBloom-Team5\shared\dbcon.php';

$sql = "
    SELECT DISTINCT questionnaires.title, programs.programName, programs.programID
    FROM questionnaires
    JOIN programs ON questionnaires.programID = programs.programID
    ORDER BY 1
";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    
    $data = [];
    $programs = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $data[] = $row;
        $programs[$row['programID']] = $row['programName'];
    }
} catch (PDOException $e) {
    echo "Query Failed: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Questionnaires</title>
    <link rel="stylesheet" href="..\..\admin\assets\css\admin_survey.css">
</head>
<header>
    <div class="left-section">
        <p><span id="title">sur</span>v<span id="title">e</span>ytes</p>
    </div>
    <div class="right-section">
        <ul class="nav">
            <li><a href="#">home</a></li>
            <li><a href="#">surveys</a></li>
            <li><a href="#">drafts</a></li>
            <li><a href="#">questions</a></li>
            <li><a href="#">logout</a></li>
        </ul>
    </div>
</header>

<body>
    <div class="search-rectangle">
    </div>
    <div class="search-container">
        <input type="text" class="search-input" placeholder="Search...">
        <div class="search-icon">
            <img src="..\..\admin\assets\imgs\search-icon.png" alt="Search Icon">
        </div>
        <button class="erase-button">
            <img src="..\..\admin\assets\imgs\cancel-icon.png" alt="Erase Icon">
        </button>
        <button class="filter-button">
            <img src="..\..\admin\assets\imgs\filter-icon.png" alt="Filter Icon">
        </button>
        <div class="dropdown-menu" id="dropdown-menu">
            <!-- Dropdown items will be populated here -->
        </div>
    </div>

    <div class="container-grid" id="data-container">
        <!-- JavaScript will insert boxes here -->
    </div>

    <script>
        const data = <?php echo json_encode($data); ?>;
        const programs = <?php echo json_encode($programs); ?>;

        const container = document.getElementById("data-container");
        const searchInput = document.querySelector(".search-input");
        const eraseButton = document.querySelector(".erase-button");
        const filterButton = document.querySelector(".filter-button");
        const dropdownMenu = document.getElementById("dropdown-menu");

        function renderBoxes(filteredData) {
            container.innerHTML = '';  
            filteredData.forEach(item => {
                const box = document.createElement("div");
                box.classList.add("box");

                const title = document.createElement("div");
                title.classList.add("box-title");
                title.textContent = item.title;

                const capsule = document.createElement("div");
                capsule.classList.add("capsule");
                capsule.textContent = item.programName;

                box.appendChild(title);
                box.appendChild(capsule);

                container.appendChild(box);
            });
        }

        renderBoxes(data);

        searchInput.addEventListener("input", function () {
            const searchText = searchInput.value.toLowerCase();

            const filteredData = data.filter(item =>
                item.title.toLowerCase().includes(searchText)
            );

            renderBoxes(filteredData);
        });

        eraseButton.addEventListener("click", function () {
            searchInput.value = "";
            renderBoxes(data);
        });

        filterButton.addEventListener("click", function () {
            dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
        });

        Object.keys(programs).forEach(programID => {
            const item = document.createElement("div");
            item.classList.add("dropdown-item");
            item.textContent = programs[programID];
            item.addEventListener("click", function () {
                const filteredData = data.filter(item => item.programID == programID);
                renderBoxes(filteredData);
                dropdownMenu.style.display = "none"; 
            });
            dropdownMenu.appendChild(item);
        });
    </script>
</body>
</html>