<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Add Questions</title>
    <link rel="stylesheet" href="../../admin/assets/css/add_Questions.css">
</head>

<body>
<header>
        <div class="left-section">
            <img id="go-back" src="../../admin/assets/imgs/less-than-icon.png" alt="go back icon">
            <p><span id="title">sur</span>v<span id="title">e</span>ytes</p>
        </div>
        <div class="right-section">
            <div class="questionnaire-container">
                <p id="questionnaire-number-container">questionnaire no.:</p>
                <p id="questionnaire-number">98651</p>
            </div>
            <button id="publish-button">PUBLISH</button>
            <img id="edit" src="../../admin/assets/imgs/edit-icon.png" alt="edit or cancel button" class="icon" onclick="toggleIcons()">
        </div>
        <script src="../../admin/assets/js/add_Questions.js" defer></script>
    </header>

    <main>
        <div class="wrapper">
            <div class="top-container">
                <p></p>
            </div>

            <div class="middle-container">
                <p id="student-satisfaction-container">Student Satisfaction with Learning Resources and Facilities</p>
            </div>

            <div class="year-container">
                <p id="year">S.Y. 2024 - 2025 | 1st sem</p>
                <div id="blank-container">
                    <p id="blank-content"></p>
                </div>
            </div>

            <div class="bottom-container">
                <button id="add-section">+ Add Section</button>
            </div>


            <div class="second-bottom-container">
                <p class="category-placeholder">I. lorem ipsum dolor sit amet</p>
                <img id="garbage" src="../../admin/assets/imgs/garbage-icon.png" alt="garbage bin">
                <button id="add-button">+ Add Question</button>
                <hr>
            </div>
        </div>

    </main>

    <footer>

        <div id="footer-div">
            <p>
                <span id="footer-title-violet">sur</span>v<span id="footer-title-violet">e</span>ytes
            </p>
        </div>
    </footer>
</body>

</html>