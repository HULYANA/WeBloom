const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'webloom',
};

async function createConnection() {
    try {
        const connection = await mysql.createConnection(dbConfig);
        console.log('Database connection successful');
        return connection;
    } catch (error) {
        console.error('Database connection failed:', error.message);
        throw error;
    }
}

module.exports = createConnection;
