const path = require('path');
const mysql = require('mysql2/promise');
const express = require('express');
const { getAllQuestionnaires, getAllPrograms, getAllDraftQuestionnaires, getCategories, getQuestions } = require('../../assets/models/adminQueries.js');

const app = express();
const bodyParser = require('body-parser');

// MySQL Pool Configuration
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'webloom',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

app.use('/admin/assets', express.static(path.join(__dirname, '../../assets')));

// Middleware
app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../../view'));
app.use(bodyParser.json());


// Route
app.get('/Admin_home', async (req, res) => {
    try {
        const [questionnaires] = await pool.query(
            'SELECT DISTINCT questionnaireID, title, datePublished, publicationStatus FROM questionnaires WHERE publicationStatus IN ("Published", "Draft", "Expired") GROUP BY questionnaireID, title, publicationStatus ORDER BY RAND() LIMIT 6');

        const [totalSurveys] = await pool.query(
            'SELECT COUNT(DISTINCT questionnaireID) AS totalSurveys FROM questionnaires');

        const [activeSurveys] = await pool.query(
            'SELECT COUNT(DISTINCT questionnaireID) AS activeSurveys FROM questionnaires WHERE publicationStatus = "Published"');

        const [pendingSurveys] = await pool.query(
            'SELECT COUNT(DISTINCT questionnaireID) AS pendingSurveys FROM questionnaires WHERE publicationStatus = "Not Published"');

        const [expiredSurveys] = await pool.query(
            'SELECT COUNT(DISTINCT questionnaireID) AS expiredSurveys FROM questionnaires WHERE publicationStatus = "Expired"');
        
        const statistics = {
            totalSurveys: totalSurveys[0].totalSurveys,
            activeSurveys: activeSurveys[0].activeSurveys,
            pendingSurveys: pendingSurveys[0].pendingSurveys,
            expiredSurveys: expiredSurveys[0].expiredSurveys,
        };

        res.render('Admin_home', {questionnaires, statistics });
    } catch (error) {
        console.error('Error fetching statistics:', error);
        res.status(500).send('Internal Server Error');
    }
});


app.get('/questionnaires', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM questionnaires');
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).send('Database error');
    }
});

app.post('/questionnaires', async (req, res) => {
    const { title, description } = req.body;
    try {
        const [result] = await pool.query(
            'INSERT INTO questionnaires (title, description) VALUES (?, ?)',
            [title, description]
        );
        res.status(201).json({ id: result.insertId });
    } catch (err) {
        console.error(err);
        res.status(500).send('Database error');
    }
});

app.get('/admin_survey', async (req, res) => {
    try {
        const questionnaires = await getAllQuestionnaires();
        const programs = await getAllPrograms();

        const programMap = programs.reduce((acc, program) => {
            acc[program.programID] = program.programName;
            return acc;
        }, {});

        res.render('admin_survey', { data: questionnaires, programs: programMap });
    } catch (error) {
        console.error("Error in admin survey route:", error.message);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/admin_drafts', async (req, res) => {
    try {
        const questionnaires = await getAllDraftQuestionnaires();
        const programs = await getAllPrograms();

        const programMap = programs.reduce((acc, program) => {
            acc[program.programID] = program.programName;
            return acc;
        }, {});

        res.render('admin_drafts', { data: questionnaires, programs: programMap });
    } catch (error) {
        console.error("Error in admin drafts route:", error.message);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/inside_survey/:title', async (req, res) => {
    const title = decodeURIComponent(req.params.title); 

    try {
        const [questionnaireRows] = await pool.query(
            'SELECT * FROM questionnaires WHERE title = ?',
            [title]
        );

        if (questionnaireRows.length === 0) {
            return res.status(404).send('Questionnaire not found');
        }

        const questionnaire = questionnaireRows[0];

        const [programRows] = await pool.query(
            'SELECT programName FROM programs WHERE programID = ?',
            [questionnaire.programID]
        );

        const programName = programRows.length > 0 ? programRows[0].programName : 'Unknown Program';

        const formattedDatePublished = questionnaire.datePublished
            ? new Date(questionnaire.datePublished).toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
              })
            : '';

        const formattedExpirationDate = questionnaire.expirationDate
            ? new Date(questionnaire.expirationDate).toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
              })
            : '';

        const [questions] = await pool.query(
            'SELECT q.questionID, q.questionText, q.questionType FROM questions q JOIN questionnaires qt ON q.questionID = qt.questionID WHERE qt.title = ?',
            [title]
        );

        const questionsWithChoicesAndStats = await Promise.all(
            questions.map(async (question) => {
                const [choices] = await pool.query(
                    'SELECT choice FROM choices WHERE questionID = ?',
                    [question.questionID]
                );

                const [responseCounts] = await pool.query(
                    `SELECT c.choice, COUNT(ra.answer) AS count
                     FROM responseAnswer ra
                     JOIN responses r ON ra.responseID = r.responseID
                     JOIN choices c ON ra.answer = c.choice
                     WHERE c.questionID = ?
                     GROUP BY c.choice, c.questionID`,
                    [question.questionID]
                );
                const choiceCounts = {};
                responseCounts.forEach((row) => {
                    choiceCounts[row.choice] = row.count;
                });

                return { 
                    ...question, 
                    choices: choices.map((c) => c.choice), 
                    choiceCounts, 
                };
            })
        );

        const [respondents] = await pool.query(
            `SELECT r.studentID, r.responseDate, u.lastName, u.firstName 
            FROM responses r 
            INNER JOIN students s ON r.studentID = s.studentID 
            INNER JOIN users u ON s.userID = u.userID 
            WHERE r.questionnaireID = ?`,
            [questionnaire.questionnaireID]
        );

        res.render('inside_survey', {
            survey: { ...questionnaire, formattedDatePublished, formattedExpirationDate },
            programName, 
            questions: questionsWithChoicesAndStats, 
            respondents 
        });
    } catch (error) {
        console.error('Error fetching data:', error);
        res.status(500).send('Server error');
    }
});

app.get('/inside_drafts/:title', async (req, res) => {
    const title = decodeURIComponent(req.params.title); 
    const categories = await getCategories();
    const allquestions = await getQuestions();

    try {
        const [questionnaireRows] = await pool.query(
            'SELECT * FROM questionnaires WHERE title = ?',
            [title]
        );

        if (questionnaireRows.length === 0) {
            return res.status(404).send('Questionnaire not found');
        }

        const questionnaire = questionnaireRows[0];

        const [programRows] = await pool.query(
            'SELECT programName FROM programs WHERE programID = ?',
            [questionnaire.programID]
        );

        const programName = programRows.length > 0 ? programRows[0].programName : 'Unknown Program';

        const formattedDatePublished = questionnaire.datePublished
            ? new Date(questionnaire.datePublished).toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
              })
            : '';

        const formattedExpirationDate = questionnaire.expirationDate
            ? new Date(questionnaire.expirationDate).toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
              })
            : '';

        const [questions] = await pool.query(
            'SELECT q.questionID, q.questionText, q.questionType FROM questions q JOIN questionnaires qt ON q.questionID = qt.questionID WHERE qt.title = ?',
            [title]
        );

        const questionsWithChoices = await Promise.all(
            questions.map(async (question) => {
                const [choices] = await pool.query(
                    'SELECT choice FROM choices WHERE questionID = ?',
                    [question.questionID]
                );
                return { ...question, choices: choices.map((c) => c.choice) };
            })
        );

        res.render('inside_drafts', {
            survey: { ...questionnaire, formattedDatePublished, formattedExpirationDate },
            programName, 
            categories: categories,
            questions: questionsWithChoices, 
            allquestions: allquestions
        });
    } catch (error) {
        console.error('Error fetching data:', error);
        res.status(500).send('Server error');
    }
});

app.get('/add_questionnaire', async (req, res) => {
    try {
        const questions = await getQuestions();
        const categories = await getCategories();
        const programs = await getAllPrograms();
        res.render('add_questionnaire', {
            questions: questions,
            categories: categories,
            programs: programs
        });
    } catch (error) {
        console.error(error);
        res.status(500).send("Error retrieving data");
    }
});


app.get('/api/questions', async (req, res) => {
    try {
        const questions = await getQuestions();
        res.json(questions);
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ error: 'Failed to fetch questions' });
    }
});

app.post('/save-questionnaire', async (req, res) => {
    const {
        title,
        program,
        schoolYear,
        semester,
        datePublished,
        expirationDate,
        publicationStatus,
        selectedQuestions
    } = req.body;

    const evaluationPeriod = `${schoolYear} ${semester}`;

    if (!title) {
        return res.status(400).json({ success: false, message: "The title is required." });
    }

    if (!selectedQuestions || selectedQuestions.length === 0) {
        return res.status(400).json({ success: false, message: "At least one question must be selected." });
    }

    try {
        const [latestIDResult] = await pool.execute(`
            SELECT MAX(questionnaireID) AS latestID FROM questionnaires
        `);
        const latestID = latestIDResult[0].latestID || 0; 
        const newQuestionnaireID = latestID + 1; 

        const values = selectedQuestions.map(questionID => [
            newQuestionnaireID,
            title,
            questionID,
            program,
            evalautionPeriod,
            publicationStatus,
            expirationDate || null, 
            datePublished || null 
        ]);

        if (values.length > 0) {
            await pool.query(`
                INSERT INTO questionnaires 
                (questionnaireID, title, questionID, programID, evalautionPeriod, publicationStatus, expirationDate, datePublished) 
                VALUES ?
            `, [values]);
        }

        res.json({ success: true });
    } catch (error) {
        console.error('Error saving questionnaire:', error);
        res.status(500).json({ success: false, message: 'Error saving questionnaire' });
    }
});


app.get('/api/available-questions/:questionnaireID', async (req, res) => {
    const questionnaireID = req.params.questionnaireID;

    try {
        const [existingQuestions] = await pool.query(
            'SELECT questionID FROM questionnaires WHERE questionnaireID = ?',
            [questionnaireID]
        );

        const existingQuestionIDs = existingQuestions.map(q => q.questionID);

        const [availableQuestions] = await pool.query(
            `SELECT questionID, questionText 
             FROM questions 
             WHERE questionID NOT IN (?)`,
            [existingQuestionIDs.length ? existingQuestionIDs : [0]] 
        );

        res.json(availableQuestions);
    } catch (error) {
        console.error('Error fetching available questions:', error);
        res.status(500).send('Internal server error');
    }
});

app.post('/api/add-questions', async (req, res) => {
    const { questionnaireID, selectedQuestionIDs } = req.body;

    if (!questionnaireID || !selectedQuestionIDs || selectedQuestionIDs.length === 0) {
        return res.status(400).json({ success: false, message: 'Invalid input' });
    }

    try {
        const values = selectedQuestionIDs.map(questionID => [
            questionnaireID,
            questionID
        ]);

        await pool.query(
            `INSERT INTO questionnaires (questionnaireID, questionID) 
             VALUES ?`,
            [values]
        );

        res.json({ success: true });
    } catch (error) {
        console.error('Error adding questions:', error);
        res.status(500).json({ success: false, message: 'Failed to add questions' });
    }
});


app.post('/publish_questionnaire/:questionnaireID', async (req, res) => {
    const { questionnaireID } = req.params;
    console.log('Received questionnaireID:', questionnaireID);

    if (!questionnaireID) {
        return res.status(400).json({ success: false, message: 'Missing questionnaire ID' });
    }

    const today = new Date();
    const expirationDate = new Date(today);
    expirationDate.setMonth(today.getMonth() + 6);

    try {
        const query = `UPDATE questionnaires 
                       SET publicationStatus = 'Published', 
                           datePublished = ?, 
                           expirationDate = ? 
                       WHERE questionnaireID = ?`;

        console.log('Executing SQL query with values:', [
            today.toISOString().split('T')[0], 
            expirationDate.toISOString().split('T')[0], 
            questionnaireID
        ]);

        const [result] = await pool.query(query, [
            today.toISOString().split('T')[0], 
            expirationDate.toISOString().split('T')[0], 
            questionnaireID
        ]);

        console.log('Result:', result);

        // Check affectedRows instead of changedRows
        if (result.affectedRows > 0) {
            console.log('Questionnaire published successfully');
            res.json({ success: true, message: 'Questionnaire published successfully.' });
        } else {
            console.log('No rows matched for questionnaireID:', questionnaireID);
            res.status(400).json({ 
                success: false, 
                message: 'No rows matched. Ensure the questionnaire ID is correct.' 
            });
        }
    } catch (error) {
        console.error('Error updating questionnaire:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

app.delete('/delete_questionnaire/:questionnaireID', async (req, res) => {
    const { questionnaireID } = req.params;
    console.log('Received questionnaireID to delete:', questionnaireID);

    if (!questionnaireID) {
        return res.status(400).json({ success: false, message: 'Missing questionnaire ID' });
    }

    try {
        const query = `DELETE FROM questionnaires WHERE questionnaireID = ?`;

        console.log('Executing SQL query to delete:', [questionnaireID]);

        const [result] = await pool.query(query, [questionnaireID]);

        console.log('Delete result:', result);

        if (result.affectedRows > 0) {
            console.log('Questionnaire deleted successfully');
            res.json({ success: true, message: 'Questionnaire deleted successfully.' });
        } else {
            console.log('No questionnaire found with the given ID:', questionnaireID);
            res.status(404).json({ success: false, message: 'No questionnaire found with the given ID.' });
        }
    } catch (error) {
        console.error('Error deleting questionnaire:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

app.delete('/delete_question_from_questionnaire', async (req, res) => {
    const { questionID, questionnaireID } = req.body;

    if (!questionID || !questionnaireID) {
        return res.status(400).json({ success: false, message: 'Missing question ID or questionnaire ID' });
    }

    try {
        const query = `
            DELETE FROM questionnaires
            WHERE questionID = ? AND questionnaireID = ?
        `;

        const result = await pool.query(query, [questionID, questionnaireID]);

        if (result.affectedRows > 0) {
            console.log(`Question with ID ${questionID} removed from questionnaire ${questionnaireID} successfully`);
            res.json({ success: true });
        } else {
            console.log(`No association found for questionID ${questionID} in questionnaireID ${questionnaireID}. It might have already been deleted.`);
            res.json({ success: true, message: 'Question already removed or no matching record found' });
        }        
    } catch (error) {
        console.error('Error removing question from questionnaire:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

app.get('/editDeleteSurvey', async (req, res) => {
    try {
        const [questionnaires] = await pool.query('SELECT * FROM questionnaires');
        const [questions] = await pool.query('SELECT * FROM questions');
        const questionsWithChoices = await Promise.all(
            questions.map(async (question) => {
                const [choices] = await pool.query(
                    'SELECT choice FROM choices WHERE questionID = ?',
                    [question.questionID]
                );
                return { ...question, choices: choices.map(c => c.choice) };
            })
        );
        const successMessage = req.query.success || ''; 
        res.render('editDeleteSurvey', { questionnaires, questions: questionsWithChoices, successMessage });
    } catch (error) {
        console.error('Error fetching surveys or questions:', error);
        res.status(500).send('Server Error: Unable to fetch survey data');
    }
});

app.post('/addQuestion', async (req, res) => {
    const { category_id, type, question, choices } = req.body;
    if (!category_id || !type || !question || !choices) {
        return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    try {

        const [result] = await pool.query(
            'INSERT INTO questions (categoryID, questionType, questionText) VALUES (?, ?, ?)',
            [category_id, type, question]
        );
        const questionID = result.insertId;
        const choicesArray = choices.split(',').map(choice => choice.trim());
        for (const choice of choicesArray) {
            await pool.query(
                'INSERT INTO choices (questionID, choice) VALUES (?, ?)',
                [questionID, choice]
            );
        }

        res.json({ success: true, message: 'Question added successfully!' });
    } catch (error) {
        console.error('Error adding question:', error.message);
        res.status(500).json({ success: false, message: 'Failed to add the question. Please try again.' });
    }
});

app.get('/searchQuestions', async (req, res) => {
    const searchQuery = req.query.search.toLowerCase();
    try {
        const [questions] = await pool.query('SELECT * FROM questions');
        const questionsWithChoices = await Promise.all(questions.map(async (question) => {
            const [choices] = await pool.query('SELECT choice FROM choices WHERE questionID = ?', [question.questionID]);
            return { ...question, choices: choices.map(c => c.choice) };
        }));

        const filteredQuestions = questionsWithChoices.filter(q =>
            q.questionText.toLowerCase().includes(searchQuery) ||
            q.choices.some(choice => choice.toLowerCase().includes(searchQuery))
        );
        res.json(filteredQuestions);
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ error: 'Failed to fetch questions' });
    }
});

app.delete('/deleteQuestion/:questionID', async (req, res) => {
    const questionID = req.params.questionID;
    try {
        const resultChoices = await pool.query('DELETE FROM choices WHERE questionID = ?', [questionID]);
        const resultQuestion = await pool.query('DELETE FROM questions WHERE questionID = ?', [questionID]);
        if (resultQuestion.affectedRows > 0) {
            return res.json({ success: true, message: 'Question and related entries deleted successfully!' });
        } else {
            return res.status(404).json({ success: false, message: 'Question not found or already deleted' });
        }
    } catch (err) {
        console.error('Error during deletion process:', err);
        return res.status(500).json({ success: false, message: 'An error occurred during the deletion process' });
    }
});


app.post('/editQuestion/:questionID', async (req, res) => {
    const { questionID } = req.params;
    const { categoryID, type, questionText, choices } = req.body;
    try {
        await pool.query(
            'UPDATE questions SET categoryID = ?, questionType = ?, questionText = ? WHERE questionID = ?',
            [categoryID, type, questionText, questionID]
        );

        await pool.query('DELETE FROM choices WHERE questionID = ?', [questionID]);
        const choicesArray = choices.split(',').map(choice => choice.trim());
        for (const choice of choicesArray) {
            await pool.query(
                'INSERT INTO choices (questionID, choice) VALUES (?, ?)',
                [questionID, choice]
            );
        }

        res.redirect('/editDeleteSurvey?success=Question+updated+successfully');
    } catch (error) {
        console.error('Error editing question:', error.message);
        res.status(500).json({ success: false, message: 'Error editing question' });
    }
});

app.get('/getQuestionDetails/:questionID', async (req, res) => {
    const { questionID } = req.params;
    try {
        const [question] = await pool.query('SELECT * FROM questions WHERE questionID = ?', [questionID]);
        const [choices] = await pool.query('SELECT choice FROM choices WHERE questionID = ?', [questionID]);

        if (question) {
            res.json({
                categoryID: question.categoryID,
                type: question.questionType,
                questionText: question.questionText,
                choices: choices.map(choice => choice.choice)
            });
        } else {
            res.status(404).json({ message: 'Question not found' });
        }
    } catch (error) {
        console.error('Error fetching question details:', error.message);
        res.status(500).json({ message: 'Error fetching question details' });
    }
});

// Start the Server
app.listen(3000, () => {
    console.log(`Server running at http://localhost:3000`);
});
