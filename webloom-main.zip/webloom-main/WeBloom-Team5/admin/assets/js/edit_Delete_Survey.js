
//to open and close the modal
document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('.add-new-question').onclick = function() {
        document.getElementById('addQuestionModal').style.display = 'block';
    }

    // Function to close the modal
    window.closeModal = function() {
        document.getElementById('addQuestionModal').style.display = 'none';
    }

    // Close the modal if the user clicks outside of it
    window.onclick = function(event) {
        if (event.target == document.getElementById('addQuestionModal')) {
            closeModal();
        }
    }

    // Close the modal when the user clicks on the close button
    document.querySelector('.close').onclick = function() {
        closeModal();
    }
});