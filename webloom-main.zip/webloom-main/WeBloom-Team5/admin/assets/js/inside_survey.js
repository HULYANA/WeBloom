document.addEventListener("DOMContentLoaded", function () {
    const buttons = document.querySelectorAll('.footer .button');
    const questionsContainer = document.querySelector('.questions-container');
    const statisticsContainer = document.querySelector('.statistics-container');
    const respondentsContainer = document.querySelector('.respondents-container');

    buttons.forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();

            buttons.forEach(btn => btn.classList.remove('selected'));

            this.classList.add('selected');

            questionsContainer.style.display = 'none';
            statisticsContainer.style.display = 'none';
            respondentsContainer.style.display = 'none';

            if (this.id === 'btn-questionnaire') {
                questionsContainer.style.display = 'flex';
            } else if (this.id === 'btn-statistics') {
                statisticsContainer.style.display = 'block';
            } else if (this.id === 'btn-respondents') {
                respondentsContainer.style.display = 'block';
            }
        });
    });
});
