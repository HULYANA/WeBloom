document.addEventListener("DOMContentLoaded", () => {
    const dataContainer = document.getElementById("data-container");
    const searchInput = document.querySelector(".search-input");
    const eraseButton = document.querySelector(".erase-button");
    const filterButton = document.querySelector(".filter-button");
    const addQuestionnaire = document.querySelector(".add-questionnaire");
    const dropdownMenu = document.getElementById("dropdown-menu");
    const boxes = Array.from(dataContainer.getElementsByClassName("box"));

    filterButton.addEventListener("click", () => {
        dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
    });

    searchInput.addEventListener("input", () => {
        const searchText = searchInput.value.toLowerCase();
        const filteredData = boxes.filter(box => {
            const title = box.querySelector(".box-title").textContent.toLowerCase();
            return title.includes(searchText);
        });
        renderBoxes(filteredData);
    });

    eraseButton.addEventListener("click", () => {
        searchInput.value = "";
        renderBoxes(boxes);
    });

    dropdownMenu.addEventListener("click", event => {
        if (event.target.classList.contains("dropdown-item")) {
            const programID = event.target.getAttribute("data-program-id");
            const filteredData = boxes.filter(box => box.getAttribute("data-program-id") === programID);
            renderBoxes(filteredData);
            dropdownMenu.style.display = "none";
        }
    });

    function renderBoxes(filteredData) {
        dataContainer.innerHTML = ''; 
        filteredData.forEach(box => {
            dataContainer.appendChild(box); 
        });
    }

    boxes.forEach(box => {
        box.addEventListener("click", () => {
            const programID = box.getAttribute("data-program-id");
            const title = box.querySelector(".box-title").textContent;
            window.location.href = `/inside_drafts/${encodeURIComponent(title)}`;
        });
    });

    renderBoxes(boxes);
    

    addQuestionnaire.addEventListener("click", () => {
        window.location.href = `/add_questionnaire`;
    });

});
