function setSchoolYear() {
    const currentYear = new Date().getFullYear();
    document.getElementById("school-year").value = `AY ${currentYear}-${currentYear + 1}`;
}

let selectedQuestions = new Set(); 

function openModal() {
    let overlay = document.createElement('div');
    overlay.classList.add('modal-overlay');
    document.body.appendChild(overlay);

    document.getElementById('question-modal').style.display = 'block';

    overlay.addEventListener('click', closeModal);
}

function closeModal() {
    document.getElementById('question-modal').style.display = 'none';
    const overlay = document.querySelector('.modal-overlay');
    if (overlay) overlay.remove();
}

function filterQuestions() {
    const categoryFilter = document.getElementById('filter-category').value;
    const questionItems = document.querySelectorAll('.question-item');

    questionItems.forEach(item => {
        const questionCategory = item.getAttribute('data-category-id');
        item.style.display = (categoryFilter === 'all' || questionCategory === categoryFilter) ? 'block' : 'none';
    });
}

function handleQuestionSelection(questionID) {
    if (selectedQuestions.has(questionID)) {
        selectedQuestions.delete(questionID);
    } else {
        selectedQuestions.add(questionID);
    }
}

let questions = [];

async function fetchQuestions() {
    try {
        const response = await fetch('/api/questions');
        questions = await response.json();
    } catch (error) {
        console.error('Error fetching questions:', error);
    }
}

function saveSelectedQuestions() {
    const selectedQuestionsContainer = document.getElementById('selected-questions');
    selectedQuestionsContainer.innerHTML = ''; 

    selectedQuestions.forEach(questionId => {
        const question = questions.find(q => q.questionID === questionId);

        if (question) {
            const choices = question.choices ? question.choices.split(',') : [];
            const questionHtml = `
                <div class="question-table-container">
                    <table>
                        <thead>
                            <tr><th colspan="2">${question.questionText}</th></tr>
                        </thead>
                        <tbody>
                            ${choices.length > 0
                                ? choices.map(choice => `<tr><td>${choice}</td></tr>`).join('')
                                : '<tr><td colspan="2" class="no-choices">No choices available</td></tr>'
                            }
                        </tbody>
                    </table>
                </div>
            `;
            selectedQuestionsContainer.innerHTML += questionHtml;
        } else {
            console.error(`Question with ID ${questionId} not found.`);
        }
    });
    closeModal();
}

fetchQuestions();

function confirmPublish() {
    document.querySelector('#confirmation-modal').setAttribute('data-action', 'publish');
    document.getElementById('confirm-yes').onclick = () => saveQuestionnaire(true);
    openConfirmationModal();
}

function confirmDrafts() {
    document.querySelector('#confirmation-modal').setAttribute('data-action', 'draft');
    document.getElementById('confirm-yes').onclick = () => saveQuestionnaire(false);
    openConfirmationModal();
}


function openConfirmationModal() {
    document.getElementById('confirmation-modal').style.display = 'block';
}

function closeConfirmationModal() {
    document.getElementById('confirmation-modal').style.display = 'none';
}

function saveQuestionnaire(isPublish) {
    const title = document.querySelector('input[type="text"]').value.trim();
    const program = document.getElementById('program').value;
    const schoolYear = document.getElementById('school-year').value;
    const semester = document.getElementById('semester').value;
    const selectedQuestionsList = Array.from(selectedQuestions);

    if (!title) {
        alert("Please provide a title for the questionnaire.");
        return;
    }

    if (selectedQuestionsList.length === 0) {
        alert("Please select at least one question.");
        return;
    }

    let datePublished = null;
    let expirationDate = null;

    if (isPublish) {
        datePublished = new Date().toISOString().split('T')[0]; 
        expirationDate = new Date();
        expirationDate.setMonth(expirationDate.getMonth() + 6); 
        expirationDate = expirationDate.toISOString().split('T')[0];
    }

    const publicationStatus = isPublish ? "Published" : "Not Published";

    fetch('/save-questionnaire', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            title,
            program,
            schoolYear,
            semester,
            datePublished, 
            expirationDate, 
            publicationStatus,
            selectedQuestions: selectedQuestionsList
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Questionnaire saved successfully!");
            window.location.reload(); 
            alert(data.message || "Error saving questionnaire.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("Error saving questionnaire.");
    });

    closeConfirmationModal();
}

document.querySelector('.publish-button').addEventListener('click', function() {
    const questionnaireID = this.getAttribute('data-questionnaire-id');  
    const confirmation = confirm("Are you sure you want to publish this questionnaire?");
    
    if (confirmation) {
        fetch(`/publish_questionnaire/${encodeURIComponent(questionnaireID)}`, {  
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            console.log('Response data:', data);  
            if (data.success) {
                alert("Questionnaire published successfully!");
                location.reload();
            } else {
                alert("There was an error publishing the questionnaire.");
            }
        })

        .catch(error => {
            console.error('Error:', error);
            alert("Error occurred while publishing.");
        });
    }
});

document.querySelectorAll('.delete-button').forEach(button => {
    button.addEventListener('click', async function () {
        const questionnaireID = this.getAttribute('data-questionnaire-id'); 

        if (!questionnaireID) {
            alert("Error: No questionnaire ID found.");
            return;
        }

        const confirmation = confirm("Are you sure you want to delete this questionnaire?");
        
        if (confirmation) {
            try {
                const response = await fetch(`/delete_questionnaire/${encodeURIComponent(questionnaireID)}`, {
                    method: 'DELETE',
                });

                const data = await response.json();

                if (data.success) {
                    alert('Questionnaire deleted successfully!');
                    window.location.href = '/admin_drafts'; 
                } else {
                    alert(data.message || 'Error deleting questionnaire.');
                }
            } catch (error) {
                console.error('Error deleting questionnaire:', error);
                alert('An error occurred while deleting the questionnaire.');
            }
        }
    });
});

document.querySelectorAll('.delete-question').forEach(button => {
    button.addEventListener('click', async function () {
        const questionText = this.nextElementSibling.querySelector('th').innerText; // Extract question text
        const confirmation = confirm(`Are you sure you want to remove this question: "${questionText}" from the questionnaire?`);

        if (confirmation) {
            try {
                const questionID = this.getAttribute('data-question-id');
                const questionnaireID = this.getAttribute('data-questionnaire-id');

                const response = await fetch(`/delete_question_from_questionnaire`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ questionID, questionnaireID })
                });

                const data = await response.json();

                if (data.success) {
                    alert('Question removed from questionnaire successfully!');
                    // Remove the question from the DOM
                    this.parentElement.remove();
                } else {
                    alert(data.message || 'Error removing the question from the questionnaire.');
                }
            } catch (error) {
                console.error('Error removing question:', error);
                alert('An error occurred while removing the question from the questionnaire.');
            }
        }
    });
});







