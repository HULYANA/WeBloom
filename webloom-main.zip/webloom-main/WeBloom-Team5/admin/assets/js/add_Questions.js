//for change icon
function toggleIcons() {
    var editIcon = document.getElementById("edit");

    if (editIcon.src.endsWith("edit-icon.png")) {
        editIcon.src = "../../../../imgs/cancel-icon.png";
    } else {
        editIcon.src = "../../../../imgs/edit-icon.png";
    }
}

// delete specific wrapper-two container
function deleteWrapper() {
    const wrapperTwo = document.querySelector('.wrapper-two');
    wrapperTwo.remove();
}


// Function to add a new .second-bottom-container below .wrapper-two
function addNewSection() {
    const newSection = document.createElement('div');

    newSection.classList.add('second-bottom-container');
    newSection.innerHTML = `
<p class="category-placeholder">I. New section added dynamically</p>
<img id="garbage" src="../../../../imgs/garbage-icon.png" alt="garbage bin">
<button id="add-button">+ Add Question</button>
<hr>
`;

    const wrapperTwo = document.querySelector('.wrapper-two');

    wrapperTwo.insertAdjacentElement('afterend', newSection);
}

document.getElementById('add-section').addEventListener('click', addNewSection);