document.addEventListener('DOMContentLoaded', () => {
    const surveyHolders = document.querySelectorAll('.survey-holder');
    const searchBtn = document.getElementById('searchBtn');
    const searchInput = document.getElementById('searchInput');
    const cardsContainer = document.getElementById('cards');
    const noResultsMessage = document.getElementById('noResults');
    const stats = {
        totalSurveys: document.getElementById('total-surveys'),
        activeSurveys: document.getElementById('active-surveys'),
        pendingSurveys: document.getElementById('pending-surveys'),
        expiredSurveys: document.getElementById('expired-surveys'),
    };
    const statistics = {
        totalSurveys: stats.totalSurveys.textContent,
        activeSurveys: stats.activeSurveys.textContent,
        pendingSurveys: stats.pendingSurveys.textContent,
        expiredSurveys: stats.expiredSurveys.textContent,
    };

    stats.totalSurveys.textContent = statistics.totalSurveys;
    stats.activeSurveys.textContent = statistics.activeSurveys;
    stats.pendingSurveys.textContent = statistics.pendingSurveys;
    stats.expiredSurveys.textContent = statistics.expiredSurveys;

    surveyHolders.forEach(holder => {
        holder.addEventListener('click', () => {
            const title = holder.querySelector('h1').textContent;
            window.location.href = `/inside_survey/${encodeURIComponent(title)}`;
        });
    });

    const filterSurveys = () => {
        const searchTerm = searchInput.value.toLowerCase().trim();
        const surveyCards = cardsContainer.querySelectorAll('.survey-holder');
        let hasResults = false;

        surveyCards.forEach(card => {
            const title = card.querySelector('h1').textContent.toLowerCase();

            if (title.includes(searchTerm)) {
                card.style.display = '';
                hasResults = true;
            } else {
                card.style.display = 'none';
            }
        });

        noResultsMessage.style.display = hasResults ? 'none' : 'block';
    };

    searchInput.addEventListener('input', filterSurveys);

    searchInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            filterSurveys(); 
        }
    });

    searchBtn.addEventListener('click', filterSurveys);
});
