const mysql = require('../../backend/node/node_modules/mysql2/promise');

// Create a connection to the database
const createConnection = async () => {
    return mysql.createConnection({
        host: 'localhost', // Replace with your database host if needed
        user: 'root',      // Replace with your database username
        password: '',      // Replace with your database password
        database: 'webloom', // Replace with your database name
    });
};

/**
 * Fetch all distinct questionnaires with program details.
 * @returns {Promise<Array>} List of questionnaires with associated program names.
 */
async function getAllQuestionnaires() {
    const query = `
        SELECT DISTINCT 
            questionnaires.title, 
            programs.programName, 
            programs.programID
        FROM questionnaires
        JOIN programs ON questionnaires.programID = programs.programID
        ORDER BY questionnaires.title ASC;
    `;

    try {
        const connection = await createConnection(); // Establish a new connection
        const [rows] = await connection.execute(query);
        await connection.end(); // Close the connection
        return rows;
    } catch (error) {
        console.error("Error fetching questionnaires:", error.message);
        throw error;
    }
}

async function getAllDraftQuestionnaires() {
    const query = `
        SELECT DISTINCT 
            questionnaires.title, 
            programs.programName, 
            programs.programID
        FROM questionnaires
        JOIN programs ON questionnaires.programID = programs.programID
        WHERE questionnaires.publicationStatus LIKE 'Not Published'
        ORDER BY questionnaires.title ASC;

    `;

    try {
        const connection = await createConnection(); // Establish a new connection
        const [rows] = await connection.execute(query);
        await connection.end(); // Close the connection
        return rows;
    } catch (error) {
        console.error("Error fetching questionnaires:", error.message);
        throw error;
    }
}

/**
 * Fetch all programs from the database.
 * @returns {Promise<Array>} List of programs.
 */
async function getAllPrograms() {
    const query = `
        SELECT programID, programName
        FROM programs;
    `;

    try {
        const connection = await createConnection(); // Establish a new connection
        const [rows] = await connection.execute(query);
        await connection.end(); // Close the connection
        return rows;
    } catch (error) {
        console.error("Error fetching programs:", error.message);
        throw error;
    }
}

async function getQuestions() {
    const query = `
        SELECT 
            q.questionID, 
            q.questionText, 
            q.questionType, 
            c.categoryID, 
            c.categoryName,
            GROUP_CONCAT(ch.choice ORDER BY ch.optionsID) AS choices
        FROM questions q
        LEFT JOIN category c ON q.categoryID = c.categoryID
        LEFT JOIN choices ch ON q.questionID = ch.questionID
        GROUP BY q.questionID
        ORDER BY q.questionText ASC;
    `;

    try {
        const connection = await createConnection(); // Establish a new connection
        const [rows] = await connection.execute(query);
        await connection.end(); // Close the connection
        return rows;
    } catch (error) {
        console.error("Error fetching questions:", error.message);
        throw error;
    }
}


async function getCategories() {
    const query = `
        SELECT categoryID, categoryName
        FROM category
        ORDER BY categoryName ASC;

    `;

    try {
        const connection = await createConnection(); // Establish a new connection
        const [rows] = await connection.execute(query);
        await connection.end(); // Close the connection
        return rows;
    } catch (error) {
        console.error("Error fetching programs:", error.message);
        throw error;
    }
}

// Export the functions for use in other files
module.exports = {
    getAllQuestionnaires,
    getAllPrograms,
    getAllDraftQuestionnaires,
    getQuestions,
    getCategories
};
