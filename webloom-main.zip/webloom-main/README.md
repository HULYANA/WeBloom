# README.txt

## Project Title: College Exit Survey
## Class Code: 9373 CS 312

### Team Name: WeBloom  
Members:
- Bumacod, Mark John D
- Binwag, Dana Wynnette
- Calsiman, Carl Allan
- Cendaña, Juliana April
- Duculan, John Christian
- Galvan, Marc Jansen

### Project Description:
The project is a College Exit Survey system that allows both students and administrators to interact with questionnaires. Students can fill out surveys, and administrators can manage questionnaires, drafts, and publish them.

### Environment Setup

#### Prerequisites:
Before setting up the project, ensure the following are installed:
- **Node.js** (version 14.x or later)
- **MySQL** (or any compatible SQL database)
- **PHP** (for the login page handling)

#### Setting Up the Project:

1. **Clone the Repository:**
   If you haven't cloned the repository, use the following command:
   git clone [<repository_url>](https://gitlab.com/2230003/webloom.git)

2. **Navigate to the Project Directory:**
   cd <project_directory>

3. **Install Node.js Dependencies:**
   Navigate to the `/admin/backend/node` directory and run the following command to install dependencies:
   npm install

4. **Set Up MySQL Database:**
   Import the SQL dump from `/shared/webloom.sql` into your MySQL server using the following command:
   mysql -u <username> -p <database_name> < shared/webloom.sql

5. **Configure Database Connection:**
   In `/admin/backend/node/server.js`, ensure that the MySQL database connection details (username, password, database name) are correctly configured.

6. **Run the Server:**
   In the `/admin/backend/node` directory, start the Node.js server with:
   node server.js
   This will start the server and expose the necessary routes for the application.

7. **Accessing the Web Application:**
   Open your browser and navigate to `http://localhost:<port>/Login.php`. Here, both students and administrators can log in to the application.

### Directory Structure:

- **/backend/node/server.js**: Starts the server, defines routes, middleware, and queries.
- **/node_modules**: Holds Node.js dependencies.
- **/student/assets/imgs**: Stores images for the student side.
- **/admin/assets/imgs**: Stores images for the admin side.
- **/admin/assets/css**: Contains CSS files for the admin side.
- **/admin/assets/js**: Contains JavaScript files for admin side functionalities (CRUD operations, modals, etc.).
- **/admin/backend/node/package.json**: Manages project dependencies and scripts.
- **/shared/webloom.sql**: SQL dump for importing into MySQL.
- **/admin/view/**: Contains EJS files for the admin side views.
- **/shared/assets**: Font styles for both student and admin sides.
- **/admin/assets/models**: Contains async JavaScript functions for database interaction.
- **/student/assets/js**: Contains scripts for the student side (questionnaire navigation, progress saving, etc.).
- **/Login.php**: Login page for user authentication (admin/student).
- **/admin/backend/node/dbcon.js**: Database connection configuration.

### Additional Notes:
- Ensure that the server is running before trying to access any of the web pages.
- The login functionality will redirect users to either the student or admin interface based on their credentials.
- For detailed documentation, refer to the individual code files and comments within the project.
